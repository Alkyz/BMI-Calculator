public class Person {
    private String lastName;
    private String firstName;
    private double heightInInches;
    private double weightInPounds;

    /**
     * This method defines our chosen class variables.
     */

    public Person (String lastName, String firstName, double heightInInches, double weightInPounds) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.heightInInches = heightInInches;
        this.weightInPounds = weightInPounds;
    }

    /**
     * This method takes or alters the defined variables from the previous method.
     */

    public String getLastName () {
        return lastName;
    }

    /**
     * This method finishes setting up the defined variables,
     */

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public double getHeightInInches() {
        return heightInInches;
    }

    public void setHeightInInches(double heightInInches) {
        this.heightInInches = heightInInches;
    }

    public double getWeightInPounds() {
        return weightInPounds;
    }

    public void setWeightInPounds(double weightInPounds) {
        this.weightInPounds = weightInPounds;
    }

    /**
     * This method concatenates our chosen variables into a string.
     */

    public String toString() {
        return "Last name: " + lastName + ".First name: " + firstName + "Height: " + heightInInches +
                ". Weight: " + weightInPounds + ".";
    }

    /**
     * This method is in charge of calculating the person's BMI and then returning it.
     */

    public double calculateBMI() {
        //Use instance variables and formula to compare BMI and return it.
        double bmi = 0;
        bmi = ((weightInPounds)/(heightInInches) * (heightInInches)) * 703;
        return bmi;
    }

    /**
     * This method takes care of determining the person's health status based on the BMI calculations.
     */

    public String determineHealth(double aBMI) {
        //Use if-statements to determine if according to BMI, the person is "healthy" or "overweight" etc. Return value.
        String healthStatus = "";

        if (aBMI < 18.5 && aBMI > 0) {
            System.out.println("You are underweight.");
        } else if (aBMI < 25) {
            System.out.println("You are healthy.");
        } else if (aBMI < 30) {
            System.out.println("You are overweight.");
        } else if (aBMI <= 39.9) {
            System.out.println("You are obese.");
        } else if (aBMI > 39.9) {
            System.out.println("You are extremely obese.");
        } else {
            System.out.println("Your BMI result is not in range according to your input values. Sorry.");
        }
        return healthStatus;
    }


    /**
     * This method suggests a recommended weight for the user based on their inputs.
     */

    public double recommendedWeight() {
        //Use the height and weight and the formula provided to determine recommended weight. Return it.
        double optimumWeight = 0;
        optimumWeight = (25 * Math.pow(heightInInches, 2)) / 703;
        return optimumWeight;
    }

}
