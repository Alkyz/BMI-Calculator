import java.util.Scanner;

public class BMIHealth {

    public static Person anyPerson;

    /**
     * This is the main method, and it calls two other methods: "createPersonObject()" and "showBMI()".
     */

    public static void main (String[] args) {
        createPersonObject();
        showBMI();
    }

    /**
     * This method converts the domain class into an object variable in which the 4 input values from the person go to.
     */

    public static void createPersonObject() {
        //1. Get all 4 values from our Person from user.
        //2. Save the values in local variables (Hint: new)
        //3. anyPerson = new(....)

        String firstName;
        String lastName;
        double height;
        double weight;

        Scanner kb = new Scanner (System.in);

        System.out.println("What is your first name?");
        firstName = kb.nextLine();
        System.out.println("What is your last name?");
        lastName = kb.nextLine();
        System.out.println("What is your height, in inches?");
        height = kb.nextDouble();
        kb.nextLine();
        System.out.println("What is your weight, in pounds?");
        weight = kb.nextDouble();
        kb.nextLine();

        Person anyPerson = new Person(firstName, lastName, height, weight);

    }

    /**
     * This method displays the object variable to the user derived from their inputs.
     */

    public static void showBMI() {
        //1. Print the Person object.
        //2. Call and store the value that determines BMI,
        //3. Call and store the return values of the method that determines health.
        //4. If the person's BMI is considered "healthy" then
        // call and store the return value of the method that calculates the person's recommended  weight & print it.
        // Hint: use .equals to compare strings.

        System.out.println(anyPerson);

        double BMI = anyPerson.calculateBMI();
        System.out.printf("%.2f", "BMI: " + BMI);

        String healthStatus = anyPerson.determineHealth(BMI);
        System.out.println("Your current health is: " + healthStatus);

        if (!healthStatus.equals("You are healthy.")) {double recommendedWeight = anyPerson.recommendedWeight();
            System.out.println("Your recommended weight: " + recommendedWeight);}

    }
}
